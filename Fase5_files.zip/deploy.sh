#!/usr/bin/env bash
# Build (esbuild ESM, @medplum/core external) and deploy via the Medplum $deploy operation.
#
# Usage:  ./deploy.sh <BOT_ID>
# Env:    MEDPLUM_BASE_URL  (default https://api.medplum.com.ar)
#         MEDPLUM_TOKEN     (required — Bearer access token for project 96cd2ddd-...)
set -euo pipefail

BOT_ID="${1:?Usage: ./deploy.sh <BOT_ID>}"
BASE_URL="${MEDPLUM_BASE_URL:-https://api.medplum.com.ar}"
TOKEN="${MEDPLUM_TOKEN:?Set MEDPLUM_TOKEN}"
OUT="dist/apply-plandefinition.mjs"

echo "› building $OUT"
npx esbuild src/bots/apply-plandefinition/index.ts \
  --bundle --platform=node --format=esm --target=es2021 \
  --external:@medplum/core \
  --outfile="$OUT"

echo "› deploying to Bot/$BOT_ID at $BASE_URL"
jq -Rs --arg fn "apply-plandefinition.mjs" \
  '{resourceType:"Parameters",parameter:[{name:"code",valueString:.},{name:"filename",valueString:$fn}]}' \
  "$OUT" \
| curl -fsS -X POST "$BASE_URL/fhir/R4/Bot/$BOT_ID/\$deploy" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/fhir+json" \
    --data-binary @- \
| jq -r '.issue[]?.details.text // "deployed"'
