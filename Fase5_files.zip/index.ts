import { BotEvent, getReferenceString, MedplumClient } from '@medplum/core';
import { Bundle, CarePlan } from '@medplum/fhirtypes';
import {
  patientReference,
  resolveActivityDefinitions,
  resolvePatient,
  resolvePlanDefinition,
  resolveProfile,
} from './helpers/resolvers';
import { buildJourneyTransaction } from './helpers/transaction-builder';
import { ApplyPlanDefinitionInput, JourneyContext } from './helpers/types';

/**
 * apply-plandefinition — Fase 5 / Bot #3 (orquestador).
 *
 * Takes a confirmed phenotype profile + a chosen combo (one of the 5 deployed
 * PlanDefinitions) and materializes the FULL journey CarePlan in one atomic
 * transaction: Tasks / Appointments / ServiceRequests / MedicationRequests, each
 * scheduled relative to the journey start and gated by the action's applicability
 * condition (FHIRPath over the patient + %profile).
 *
 * Design: thin orchestrator over single-responsibility helpers (E1 / ADR-021).
 *   resolvers           — fetch Patient, PlanDefinition, ActivityDefinitions, profile
 *   journey-sequencer   — compute per-action offsets (relatedAction + timing)
 *   condition-evaluator — applicability gating via FHIRPath
 *   activity-factory    — ActivityDefinition -> concrete request resource
 *   transaction-builder — assemble the atomic CarePlan + steps bundle
 *
 * Returns the persisted CarePlan.
 */
export async function handler(
  medplum: MedplumClient,
  event: BotEvent<ApplyPlanDefinitionInput>,
): Promise<CarePlan> {
  const input = event.input;
  if (!input?.patient || !input?.combo) {
    throw new Error('apply-plandefinition requires { patient, combo }');
  }

  // 1. Resolve the world.
  const [patient, plan] = await Promise.all([
    resolvePatient(medplum, input.patient),
    resolvePlanDefinition(medplum, input.combo),
  ]);
  const [activityDefs, profile] = await Promise.all([
    resolveActivityDefinitions(medplum, plan),
    resolveProfile(medplum, input.profile),
  ]);

  // 2. Build the journey context.
  const ctx: JourneyContext = {
    patient,
    patientRef: patientReference(patient),
    profile,
    start: input.start ? new Date(input.start) : new Date(),
    author: input.author,
  };

  // 3. Assemble the atomic transaction.
  const { bundle, carePlanFullUrl, materialized, skipped } = buildJourneyTransaction(
    plan,
    activityDefs,
    ctx,
  );

  console.log(
    `[apply-plandefinition] combo=${plan.id} patient=${getReferenceString(patient)} ` +
      `steps=${materialized} skipped=${skipped}`,
  );

  // 4. Execute and return the persisted CarePlan.
  const response = (await medplum.executeBatch(bundle)) as Bundle;
  return extractCarePlan(response, carePlanFullUrl);
}

function extractCarePlan(response: Bundle, carePlanFullUrl: string): CarePlan {
  const entries = response.entry ?? [];

  // Prefer the entry that maps back to our CarePlan fullUrl when echoed.
  for (const e of entries) {
    if (e.fullUrl === carePlanFullUrl && e.resource?.resourceType === 'CarePlan') {
      return e.resource as CarePlan;
    }
  }
  // Otherwise the first CarePlan in the response (the transaction creates exactly one).
  for (const e of entries) {
    if (e.resource?.resourceType === 'CarePlan') {
      return e.resource as CarePlan;
    }
  }

  const statuses = entries.map((e) => e.response?.status).join(', ');
  throw new Error(`apply-plandefinition: CarePlan not found in transaction response (statuses: ${statuses})`);
}
