# Fase 5 · Bot #3 — `apply-plandefinition` (Orquestador)

Runbook de extremo a extremo: del código a un CarePlan persistido y verificado en
`api.medplum.com.ar`. Proyecto Medplum `96cd2ddd-f261-490a-9928-31cb9f8bc3d8`.

> Patrón de build/deploy idéntico a `lab-ingestion` y `evaluate-fenotipo`:
> esbuild ESM + `@medplum/core` como external, deploy vía `curl` al `$deploy`.

---

## 0. Qué hace el bot

Toma un **perfil de fenotipo confirmado** + un **combo elegido** (uno de los 5
PlanDefinitions `pd-combo-*`) y materializa el **journey completo** en una sola
transacción atómica: `CarePlan` + sus `ServiceRequest` / `Appointment` / `Task` /
`MedicationRequest`, cada uno agendado relativo al inicio del journey y filtrado por la
condición `applicability` de su acción (FHIRPath sobre el Patient + `%profile`).

Entrada → salida:

```
{ patient, combo, profile?, start?, author? }   ──▶   CarePlan persistido (con activity[] → cada paso)
```

Diseño E1 / ADR-021 — orquestador delgado sobre helpers de responsabilidad única:

| Archivo | Responsabilidad |
|---|---|
| `index.ts` | Handler. Resuelve mundo → arma contexto → construye transacción → ejecuta → devuelve CarePlan |
| `helpers/resolvers.ts` | Lee Patient, PlanDefinition (id→name→url), ActivityDefinitions, profile |
| `helpers/journey-sequencer.ts` | Offset por acción: `relatedAction` → `timingDuration` → `boundsDuration` → `timingDateTime` |
| `helpers/condition-evaluator.ts` | Gating `applicability` vía FHIRPath; **fail-closed** |
| `helpers/activity-factory.ts` | `ActivityDefinition.kind` → recurso de pedido concreto |
| `helpers/transaction-builder.ts` | Ensambla el Bundle atómico (CarePlan + pasos, cross-refs `urn:uuid`) |

---

## 1. Prerrequisitos

- Node ≥ 18, `npm`
- `jq` y `curl` en el PATH (los scripts `.sh` los usan)
- Un access token del proyecto exportado como `MEDPLUM_TOKEN`

```bash
export MEDPLUM_BASE_URL="https://api.medplum.com.ar"
export MEDPLUM_TOKEN="<access_token>"
```

> El token se obtiene con tu flujo OAuth client-credentials habitual del proyecto. No lo
> pongas en archivos versionados.

---

## 2. Instalar, typecheck y test offline

```bash
npm install
npm run typecheck       # tsc --noEmit  → debe salir limpio
npm test                # offline E2E (7 checks) + resolver del perfil confirmado (4 checks)
```

El test offline corre el núcleo puro (`buildJourneyTransaction`) contra los fixtures de
`bio-energy` **sin servidor**, y verifica:

- perfil `eligible` → 4 pasos materializados, 0 omitidos
- perfil `notEligible` → IV Boost filtrado por condición (3 pasos, 1 omitido)
- timing relativo: día 0 / +2 / +5 / +28 desde `start`
- mapeo de `kind` → `ServiceRequest` / `MedicationRequest` / `Task` / `Appointment`
- cada paso referencia el `CarePlan` por `urn:uuid`

Salida esperada:

```
apply-plandefinition — offline E2E
  ✓ eligible: 4 steps materialized, 0 skipped
  ✓ eligible: bundle is an atomic transaction (CarePlan + 4 steps = 5 entries)
  ✓ eligible: kind mapping -> ServiceRequest, MedicationRequest, Task, Appointment
  ✓ eligible: relative timing lands on day 0 / +2 / +5 / +28
  ✓ eligible: CarePlan links all 4 activities and instantiates the plan canonical
  ✓ eligible: every materialized step references the CarePlan fullUrl
  ✓ notEligible: IV Boost gated out -> 3 steps, 1 skipped

7 checks passed.
```

---

## 3. Crear/registrar el recurso `Bot`

Si el Bot ya existe, saltá al paso 4 con su id. Para crearlo:

```bash
BOT_ID=$(curl -fsS -X POST "$MEDPLUM_BASE_URL/fhir/R4/Bot" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Bot",
    "name": "apply-plandefinition",
    "description": "Fase 5 Bot #3 — orquestador PlanDefinition -> CarePlan journey",
    "runtimeVersion": "awslambda"
  }' | jq -r '.id')
echo "BOT_ID=$BOT_ID"
```

> Para invocarlo por `$execute` también necesitás un `ProjectMembership` con `AccessPolicy`
> que permita `CarePlan`, `Task`, `Appointment`, `ServiceRequest`, `MedicationRequest` (write)
> y lectura de `Patient` / `PlanDefinition` / `ActivityDefinition`. Es el mismo patrón de
> AccessPolicy que ya usás; este bot no introduce nuevos resource types fuera de esa lista.

---

## 4. Build + deploy

```bash
npm run build                 # → dist/apply-plandefinition.mjs (ESM, core external)
./deploy.sh "$BOT_ID"         # esbuild + curl al $deploy
```

`deploy.sh` empaqueta el `.mjs` en un `Parameters` (`code` + `filename`) y hace
`POST Bot/<id>/$deploy`. Verificá que la respuesta no traiga `issue[].severity = error`.

---

## 5. Sembrar fixtures (una vez por entorno)

Los fixtures usan `PUT ?url=` (upsert idempotente), así que es seguro re-correrlos.

```bash
# ActivityDefinitions (4, una por kind)
curl -fsS -X POST "$MEDPLUM_BASE_URL/fhir/R4" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" -H "Content-Type: application/fhir+json" \
  --data-binary @fixtures/bio-energy/ActivityDefinitions.bundle.json | jq '.type'

# PlanDefinition pd-combo-bio-energy
jq '{resourceType:"Bundle",type:"transaction",entry:[{request:{method:"PUT",url:("PlanDefinition?url="+.url)},resource:.}]}' \
  fixtures/bio-energy/PlanDefinition-pd-combo-bio-energy.json \
| curl -fsS -X POST "$MEDPLUM_BASE_URL/fhir/R4" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" -H "Content-Type: application/fhir+json" \
  --data-binary @- | jq '.type'
```

> En producción reemplazá estos fixtures por tus 5 PlanDefinitions y 7 ActivityDefinitions
> reales ya deployadas. Los fixtures son solo el caso de prueba de `bio-energy`.

---

## 6. Smoke E2E contra el servidor

```bash
./test/smoke-e2e.sh "$BOT_ID"
```

El script: siembra fixtures → crea un Patient de prueba → invoca el bot con perfil
`eligible` → verifica el CarePlan y sus pasos. Salida esperada:

```
› 4/4 invoking Bot/<id> with eligible profile
    CarePlan/<id>
› verifying journey steps
    CarePlan.activity = 4 (expect 4)
    ServiceRequest basedOn CarePlan = 1 (expect 1)
    Appointment for patient = 1 (expect >=1)
✓ smoke E2E passed — CarePlan/<id>
```

Invocación manual equivalente (un solo combo, perfil inline):

```bash
curl -fsS -X POST "$MEDPLUM_BASE_URL/fhir/R4/Bot/$BOT_ID/\$execute" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" -H "Content-Type: application/fhir+json" \
  -d '{
    "patient": "Patient/<PATIENT_ID>",
    "combo": "pd-combo-bio-energy",
    "profile": { "fenotipo": "bio-energy", "eligible": true, "score": 82 },
    "start": "2026-06-01T09:00:00.000Z"
  }' | jq '{id, status, activities: (.activity | length)}'
```

---

## 7. Resultados esperados

Para el combo `bio-energy` con perfil `eligible` y `start = 2026-06-01T09:00Z`:

| Acción (PlanDefinition) | ActivityDefinition.kind | Recurso generado | Inicio agendado |
|---|---|---|---|
| `baseline-eval` | ServiceRequest | `ServiceRequest` (occurrenceDateTime) | día 0 |
| `iv-boost-session` *(gated)* | MedicationRequest | `MedicationRequest` | +2 días |
| `followup-call` | Task | `Task` (executionPeriod) | +5 días |
| `reassessment` | Appointment | `Appointment` (start/end) | +28 días |

- `CarePlan.status = active`, `intent = plan`, `instantiatesCanonical = [.../pd-combo-bio-energy]`
- `CarePlan.activity` tiene 4 entradas, cada una `reference` → su paso
- Cada paso (salvo Appointment) trae `basedOn → CarePlan/<id>`
- Con perfil `notEligible` (`eligible:false`) el `MedicationRequest` IV Boost **no** se crea
  (condición `%profile.eligible = true` falsa); CarePlan queda con 3 actividades

Verificación post-hoc:

```bash
CP=<CAREPLAN_ID>
curl -fsS "$MEDPLUM_BASE_URL/fhir/R4/CarePlan/$CP" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" | jq '{status, intent, activities:(.activity|length)}'
curl -fsS "$MEDPLUM_BASE_URL/fhir/R4/Task?based-on=CarePlan/$CP" \
  -H "Authorization: Bearer $MEDPLUM_TOKEN" | jq '.total'
```

---

## 8. Contrato de entrada (referencia)

```ts
interface ApplyPlanDefinitionInput {
  patient: string | Reference<Patient>;   // "Patient/<id>" | id | Reference
  combo: string;                           // id → name → canonical url (en ese orden)
  profile?: Reference | Record<string, unknown>;  // de evaluate-fenotipo; expuesto como %profile
  start?: string;                          // ISO-8601; ancla TODO el timing relativo (default: now)
  author?: AuthorReference;                // requester/author de los recursos generados
}
```

Variables FHIRPath disponibles en las condiciones `applicability`:

- `%profile` → el perfil **confirmado** resuelto (Observation `fenotipo-confirmado`,
  status `final`). Las condiciones lo leen así:
  `%profile.valueCodeableConcept.coding.where(system='<iscca>' and code='menopausia').exists()`
- `%patient` / `%subject` → el recurso Patient
- root de evaluación → el Patient

> **Perfil confirmado, no provisional.** Si no pasás `profile` en el input, el Bot resuelve
> la Observation `fenotipo-confirmado` (status `final`) del paciente. Si solo hay
> provisional, **falla-cerrado** ("awaiting médico confirmation") — enforça el
> human-in-the-loop de evaluate-fenotipo Layer 3. Pasar `profile` explícito (Reference u
> objeto) saltea la resolución (útil para tests / invocación médica directa).

> **Sin navegación inversa.** FHIRPath no resuelve `%subject.observation...` (Patient no
> tiene esa propiedad → colapsa a `false` en silencio). Leé siempre `%profile`. Detalle y
> expresiones por combo en `docs/CALIBRATION-applicability.md`.

> **Convención de keys (verificada):** en `@medplum/core` v3.2 las variables se registran
> **con** el prefijo `%` (`{ '%profile': ... }`). El test offline lo cubre; si subís de
> versión, re-corré `npm test` antes de deployar.

---

## 9. Decisiones de diseño y bordes

- **Atomicidad:** todo el journey es un único Bundle `transaction` → o se crea entero o
  nada. No hay estados parciales.
- **Fail-closed en gating:** condición con lenguaje no soportado o que tira error → la
  acción **no** se materializa (nunca emitimos un paso sobre una regla no verificada).
- **AD no resuelta:** si una acción referencia un `definitionCanonical` que no existe, el
  paso se omite (cuenta en `skipped`) y se loguea; no se crea un recurso vacío.
- **Acción sin `definitionCanonical`:** se captura igual como `Task` para no perder pasos
  del journey.
- **`Appointment.basedOn` (R4)** solo admite `ServiceRequest`, así que el back-link al
  CarePlan va por `CarePlan.activity[].reference`, no por `basedOn` en el Appointment.
- **Guard de ciclos** en `relatedAction`: un grafo cíclico colapsa a offset 0 en vez de
  colgar.

---

## 10. Calibración de los otros 4 combos

Las 3 preguntas de diseño quedaron resueltas (detalle y expresiones verificadas en
`docs/CALIBRATION-applicability.md`):

- **Modelo (b) médico-driven** — el médico elige el combo; `applicability` solo filtra qué
  acciones dentro del combo aplican. Ya implementado (el `combo` es input explícito).
- **Perfil confirmado** — Observation `fenotipo-confirmado` status `final`; el Bot la
  resuelve y falla-cerrado si solo hay provisional.
- **Matriz perfil→combo** — `fixtures/perfil-combo-matrix.json`, asesora y marcada
  `PENDING_CLINICAL_VALIDATION` (decisión de Conrado/Stephanie); no cableada a la ejecución.

Para pasar `recovery / balance / iv-boost / elite` a producción:

1. Validación clínica de la matriz y de los perfiles objetivo por combo.
2. Escribir las `applicability` en las 5 PlanDefinitions reales con el patrón
   `%profile.valueCodeableConcept.coding.where(system='<iscca>' and code in (...)).exists()`
   (solo en acciones perfil-dependientes; las demás aplican siempre dentro del combo).
3. **Cobertura de `kind`** — kinds fuera de los 4 soportados degradan a `Task` hoy; para
   `CommunicationRequest` u otro, se agrega un branch en `activity-factory.ts` (1 función).
4. Por combo: fixture + extender `test/e2e-offline.test.ts`, luego `./test/smoke-e2e.sh`.
