/**
 * Confirmed-profile resolution tests (no server).
 *
 * Exercises the human-in-the-loop gate: the orchestrator reads ONLY the confirmed
 * phenotype (Observation `fenotipo-confirmado`, status `final`) and refuses to act when
 * a patient has only a provisional one.
 *
 * Run:  npx tsx test/resolver-confirmed-profile.test.ts
 */
import assert from 'node:assert/strict';
import { Observation, Patient } from '@medplum/fhirtypes';
import {
  CONFIRMED_CODE,
  hasProvisionalOnly,
  OBSERVATION_TYPE_SYSTEM,
  profileClinicalCode,
  PROVISIONAL_CODE,
  resolveConfirmedProfile,
} from '../src/bots/apply-plandefinition/helpers/resolvers';

const PATIENT: Patient = { resourceType: 'Patient', id: '474d9758' };

function obs(code: string, status: 'preliminary' | 'final', perfil: string): Observation {
  return {
    resourceType: 'Observation',
    status,
    code: { coding: [{ system: OBSERVATION_TYPE_SYSTEM, code }] },
    subject: { reference: 'Patient/474d9758' },
    valueCodeableConcept: {
      coding: [{ system: 'https://biowellness.ar/fhir/CodeSystem/iscca-perfil-clinico', code: perfil }],
    },
  };
}

/** Minimal MedplumClient stand-in: serves a fixed Observation store with simple filtering. */
function mockMedplum(store: Observation[]) {
  return {
    async searchResources(_rt: 'Observation', params: Record<string, string>): Promise<Observation[]> {
      const wantStatus = params.status;
      const codeParam = params.code; // "system|code"
      const wantCode = codeParam?.split('|')[1];
      return store.filter(
        (o) =>
          (!wantStatus || o.status === wantStatus) &&
          (!wantCode || o.code?.coding?.some((c) => c.code === wantCode)),
      );
    },
  } as unknown as Parameters<typeof resolveConfirmedProfile>[0];
}

let passed = 0;
const check = async (name: string, fn: () => void | Promise<void>) => {
  await fn();
  passed++;
  console.log(`  ✓ ${name}`);
};

console.log('apply-plandefinition — confirmed-profile resolution');

await check('resolves the confirmed (final) Observation, ignoring provisional', async () => {
  const medplum = mockMedplum([
    obs(PROVISIONAL_CODE, 'preliminary', 'menopausia'),
    obs(CONFIRMED_CODE, 'final', 'cardio-metabolico'),
  ]);
  const resolved = await resolveConfirmedProfile(medplum, PATIENT);
  assert.ok(resolved, 'a confirmed profile is returned');
  assert.equal(profileClinicalCode(resolved), 'cardio-metabolico');
});

await check('returns undefined when only a provisional profile exists', async () => {
  const medplum = mockMedplum([obs(PROVISIONAL_CODE, 'preliminary', 'menopausia')]);
  const resolved = await resolveConfirmedProfile(medplum, PATIENT);
  assert.equal(resolved, undefined);
});

await check('hasProvisionalOnly detects the awaiting-confirmation state', async () => {
  const medplum = mockMedplum([obs(PROVISIONAL_CODE, 'preliminary', 'menopausia')]);
  assert.equal(await hasProvisionalOnly(medplum, PATIENT), true);
});

await check('profileClinicalCode reads the iscca-perfil-clinico code', () => {
  assert.equal(profileClinicalCode(obs(CONFIRMED_CODE, 'final', 'longevidad-biohacking')), 'longevidad-biohacking');
  assert.equal(profileClinicalCode({}), undefined);
});

console.log(`\n${passed} checks passed.`);
